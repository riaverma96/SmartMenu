//

//  MapViewController.swift

//  SmartMenu

//

//  Created by Ria Verma on 10/15/17.

//  Copyright © 2017 Hex. All rights reserved.

//



import UIKit

import MapKit

import CoreLocation



class MapViewController: UIViewController, CLLocationManagerDelegate {
    
    
    
    @IBOutlet weak var map: MKMapView!
    
    let locationManager = CLLocationManager()
    
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let location = locations[0]
        
        let span: MKCoordinateSpan = MKCoordinateSpanMake(0.01, 0.01)
        
        let userLocation: CLLocationCoordinate2D = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude)
        
        let region: MKCoordinateRegion = MKCoordinateRegionMake(userLocation, span)
        
        
        
        map.setRegion(region, animated: true)
        
        self.map.showsUserLocation = true
        
    }
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        locationManager.delegate = self
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        locationManager.requestWhenInUseAuthorization()
        
        locationManager.startUpdatingLocation()
        
        
        do {
            
            let file = Bundle.main.url(forResource: "menu", withExtension: "json")
            
            if (file != nil) {
                
                let data = try Data(contentsOf: file!)
                
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                
                let object = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
                
                if let dictionary = object as? [String: AnyObject] {
                    
                    print("json is a dictionary")
                    
                    readJSONObject(object: dictionary)
                    
                } else if json is [Any] {
                    if let tm = json as? NSArray {
                        for obj in tm {
                            print("inside loop")
                            if let dict = obj as? NSDictionary {
                                let items = dict["items"] as? NSArray
                                print("--------------------------------")
                                print("items", items)
                                print("--------------------------------")
                                for item in items! {
                                    let price = dict.value(forKey: "basePrice")
                                    let name = dict.value(forKey: "name")
                                    print("name = ", name)
                                    print("price = ", price)
                                }
                            }
                        }
                        print("json is a [NSArray]")
                    } else {
                        print("dead")
                    }
                    
                    print("json is an array")
                    
                
                    
                } else {
                    
                    print("JSON is invalid")
                    
                }
                
            } else {
                
                print("no file")
                
            }
            
        } catch {
            
            print(error.localizedDescription)
            
        }
        
    }
    
    func readJSONArray (myArray: Any) {
        
    }
    
    
    func readJSONObject(object: [String: AnyObject]) {
        
        guard let items = object["items"] as? [[String: AnyObject]] else { return }
        
        for item in items {
            
            guard let name = item["name"] as? String,
            
                let price = item["baseprice"] as? Double else { break }
            
            print("name = ", name)
            
            print("price = ", price)
            
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
        
    }
    
    
    
    
    
}
